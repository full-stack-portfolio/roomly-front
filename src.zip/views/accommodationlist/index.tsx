import React from 'react'

export default function accommodationList() {
  return (
    <div>index</div>
  )
}
