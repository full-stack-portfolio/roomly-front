// interface: Response Dto 객체 타입 //
export default interface ResponseDto {
    code: string;
    message: string;
}