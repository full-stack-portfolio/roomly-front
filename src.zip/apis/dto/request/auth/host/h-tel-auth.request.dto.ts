// interface: 전화번호 인증 Request Body Dto //
export default interface TelAuthRequestDto {
    hostTelNumber: string;
}