// interface: 중복 확인 Request Body Dto //
export default interface IdCheckRequestDto {
    guestId : string;
}   