import { MyAccommodationManagement } from 'src/component/mypagehost/MyAccommodationManagement';
import './style.css';
import React from 'react'

export default function MyAccommodationManagementView() {
  return (
    <div>
      <MyAccommodationManagement />
    </div>
  )
}